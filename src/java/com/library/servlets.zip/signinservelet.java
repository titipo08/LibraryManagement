package com.library;

import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.sql.*;
public class signinservelet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
         PrintWriter out = response.getWriter(); 
         String user=request.getParameter("name");
         String code=request.getParameter("id");
         Connection con=null;
         PreparedStatement stmt;
            stmt = null;
            try{
                 Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost/librarymanagement","root","kinjal");
             stmt=con.prepareStatement("select name,code from users where name=? and code=?");
            }
            catch(ClassNotFoundException | IllegalAccessException | InstantiationException | SQLException e)
         {
             out.println(e.getMessage());
         }
        try {
            stmt.setString(1, user);
            stmt.setString(2,code);
            ResultSet rs = stmt.executeQuery();
            if(rs.next())
            {
                response.sendRedirect("selection1.html");
                
            }
            else
            {
            
        response.sendRedirect("index.html#registerForm");
            }
        } catch (SQLException ex) {
            System.getLogger(signinservelet.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }
       
    }

}
