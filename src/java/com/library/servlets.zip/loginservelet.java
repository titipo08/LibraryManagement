/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.library;

import java.io.*;
import java.util.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.sql.*;

public class loginservelet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String name = request.getParameter("name");
        Random rand = new Random();

        char letter = (char) ('A' + rand.nextInt(26)); // random alphabet
        int number = rand.nextInt(9000) + 1000;        // 4 digit number

        String uqcode = letter + "" + number;
        Connection con = null;
        PreparedStatement stmt;
        stmt = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/librarymanagement", "root", "kinjal");
            stmt = con.prepareStatement("insert into users(name,code) values(?,?)");
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException | SQLException e) {
            out.println(e.getMessage());
        }
        try {

            stmt.setString(1, name);
            stmt.setString(2, uqcode);
            stmt.executeUpdate();
            HttpSession session = request.getSession(true);
            session.setAttribute("unique_code", uqcode);

            System.out.println("Stored in session: " + uqcode);
            response.sendRedirect("index.html?code=" + uqcode + "#loginForm");
        } catch (SQLException e) {
            out.println(e.getMessage());
        }

    }

}
