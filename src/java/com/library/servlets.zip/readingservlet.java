/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.library;

import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.net.URLEncoder;
import java.time.*;
import java.sql.*;

public class readingservlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);

        if (session == null) {
            System.out.println("Session not found");
            response.sendRedirect("index.html");
            return;
        }

        String code = (String) session.getAttribute("unique_code");

        System.out.println("Code from session: " + code);
        Connection con = null;
        String name = "", info = "";
        System.out.println("Code from context: " + code);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/librarymanagement", "root", "kinjal");
            PreparedStatement stmt = con.prepareStatement(
                    "SELECT name FROM users WHERE code = ?"
            );

            stmt.setString(1, code);

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                name = rs.getString("name");
            }

            LocalDate date = LocalDate.now();
            LocalTime time = LocalTime.now();
            String formattedTime = time.format(java.time.format.DateTimeFormatter.ofPattern("HH:mm:ss"));
            info = "Name : " + name + " | Date : " + date + " | Time : " + formattedTime;
            response.sendRedirect("reading.html?display=" + URLEncoder.encode(info, "UTF-8"));

        } catch (Exception e) {
            e.printStackTrace();

        }
    }
}
